module.exports.DB_URI = 'mongodb://localhost:27017/bookstore';
module.exports.PORT = 3000;
module.exports.AUTH_COOKIE_TOKEN_NAME = 'authCookieToken';
module.exports.AUTH_KEY = 'dagTad key';

module.exports.AUTH_COOKIE_AGE = 2 * 24 * 60 * 60 * 1000; // 2 days
module.exports.SIGN_OUT_COOKIE_AGE = 1000; // 1 second
