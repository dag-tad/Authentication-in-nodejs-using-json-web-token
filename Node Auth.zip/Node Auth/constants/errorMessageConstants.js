module.exports.UN_AUTHORIZED_ERROR = 'You are not authorized user. Please sign in first.';
module.exports.SIGN_UP_ERROR = 'User not created.';