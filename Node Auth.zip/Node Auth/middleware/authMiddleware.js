const token = require('jsonwebtoken');

const appLevelConstants = require('../constants/appLevelConstants');
const appLevelErrorMessageConstants = require('../constants/errorMessageConstants');

const key = appLevelConstants.AUTH_KEY;
const authCookieAge = appLevelConstants.AUTH_COOKIE_AGE;
const unAuthorizedErrorMessage = appLevelErrorMessageConstants.UN_AUTHORIZED_ERROR;

module.exports.checkAuth = (req, res, next) => {

    if(req.cookies.authCookieToken){
    const authCookieToken = req.cookies.authCookieToken;
    console.log(authCookieToken);
    token.verify(authCookieToken, key, (err, tkn) => {
            if(err){
                res.status(401).json({ 'Error' : unAuthorizedErrorMessage});
            }
            else{
                next();
            }
        });
    }
    else{
        res.status(401).json({ 'Error' : unAuthorizedErrorMessage});
    }
}