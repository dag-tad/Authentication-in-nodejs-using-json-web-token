const token = require('jsonwebtoken');

const User = require('../models/user');
const appLevelConstants = require('../constants/appLevelConstants');
const errorMessageConstants = require('../constants/errorMessageConstants');

const key = appLevelConstants.AUTH_KEY;
const authCookieAge = appLevelConstants.AUTH_COOKIE_AGE;
const signOutCookieAge = appLevelConstants.SIGN_OUT_COOKIE_AGE;
const authCookieToken = appLevelConstants.AUTH_COOKIE_TOKEN_NAME;
const signInError = errorMessageConstants.SIGN_UP_ERROR;

const getToken = function(id){
    return token.sign({ id }, key, { expiresIn : authCookieAge });
}

module.exports.signUpPost = async (req, res) => {
    const {firstName, fatherName, userName, password} = req.body;
    try{
        const user = await User.create({firstName, fatherName, userName, password});

        const token = await getToken(user._id);

        res.cookie(SauthCookieToken, token, { httpOnly : true, maxAge : authCookieAge});
        res.status(201).json(user);
    }
    catch(error){
        res.status(400).json({ 'Error' : signInError});
    }
}

module.exports.signInPost = async (req, res) => {
    const { userName, password } = req.body;
    
    try{
        const user = await User.signIn(userName, password);

        const token = await getToken(user._id);
        res.cookie(authCookieToken, token, { httpOnly : true, maxAge : authCookieAge});

        res.json(user);
    }
    catch(err){
        const errors = err.message;
        res.status(400).json({ errors });
    }
}

module.exports.signOutGet = (req, res) => {
    res.cookie(authCookieToken, '', { httpOnly : true, maxAge : signOutCookieAge });
    res.send('You are successfully signed out.');
}