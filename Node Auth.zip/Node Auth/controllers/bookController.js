const Book = require('../models/book');

const handleBookError = (err) => {
    let bookError = { id : '', title : '', author : '', price : '' };

    if(err.message.includes('book validation failed')){
        Object.values(err.errors).forEach(({ properties }) => {
            bookError[properties.path] = properties.message;
        });
    }

    return bookError;
}

module.exports.addBook = async (req, res) => {
    const { id, title, author, price } = req.body;
    try{
        const book = await Book.create({ id, title, author, price });
        res.status(201).json(book);
    }
    catch(err){
        const bookErrors = handleBookError(err);
        res.status(400).json({ bookErrors });
    }
}

module.exports.listBooks = async (req, res) => {
    const books = await Book.find(function(err, result){
        if(err){
            console.log(err);
        }
        else{
            res.status(200).json(result);
        }
    });
}

module.exports.getBookDetail = async (req, res) => {
    const id = req.params.id;
    try{
        const book = await Book.find({id: id});
        res.status(200).json(book);
    }
    catch(error){
        console.log(error);
    }
}

module.exports.deleteBook = async (req, res) => {
    const id = req.params.id;
    try{
        const book = await Book.remove({id: id});
        res.status(200).json(book);
    }
    catch(error){
        console.log(error);
    }
}