const Router = require('express');

const authController = require('../controllers/authController');

const router = Router();

//this end point is not required because i don't have a sign up view to render
/*router.get('sign-up', (req, res) => {
    res.render('sign up page');
});

this end point is not required because i don't have a sign in view to render

router.get('sign-in', (req, res) => {
    res.render('sign in page');
});*/
router.post('/signup', authController.signUpPost);
router.post('/signin', authController.signInPost);
router.get('/signout', authController.signOutGet);

module.exports = router;