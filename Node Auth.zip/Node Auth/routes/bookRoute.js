const Router = require('express');

const bookController = require('../controllers/bookController');
const { checkAuth } = require('../middleware/authMiddleware');

const bookRouter = Router();

bookRouter.get('/list', checkAuth, bookController.listBooks);
bookRouter.get('/detail/:id', checkAuth, bookController.getBookDetail);
bookRouter.post('/add', checkAuth, bookController.addBook);
bookRouter.delete('/delete/:id', checkAuth, bookController.deleteBook);

module.exports = bookRouter;