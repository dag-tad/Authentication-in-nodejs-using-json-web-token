const express = require('express');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');

const appLevelConstants = require('./constants/appLevelConstants');
const authRoute = require('./routes/authRoute');
const bookRoute = require('./routes/bookRoute');

const app = express();

const port = appLevelConstants.PORT;
const uri = appLevelConstants.DB_URI;
app.use(express.json());

mongoose.connect(uri, {useNewUrlParser : true, useUnifiedTopology : true})
        .then((result) => app.listen(port))
        .catch((error) => console.log(error));

app.use(cookieParser());
app.use('/', authRoute);
app.use('/books', bookRoute);