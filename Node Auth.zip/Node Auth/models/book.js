const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
    id: {
        type: Number,
    },
    title: {
        type: String,
        minlength: [3, 'Title should be at least 3 characters.'],
        required: [true, 'Book title is a required field.']
    },
    author: {
        type: String,
        minlength: [3, 'Author should be at least 3 characters.'],
        required: [true, 'Author is a required field.']
    },
    price: {
        type: Number,
    }
});

const Book = mongoose.model('book', bookSchema);

module.exports = Book;