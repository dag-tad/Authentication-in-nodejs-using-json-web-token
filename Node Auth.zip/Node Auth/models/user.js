const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
    firstName: {
        type: String,
        minlength: [3, 'First name is a required field.'],
        required: [true, 'First name is a required field.']
    },
    fatherName: {
        type: String,
        minlength: [3, 'Father name is a required field.'],
        required: [true, 'Father name is a required field.']
    },
    userName: {
        type: String,
        minlength: [3, 'User name should be at least 3 characters.'],
        required: [true, 'User name is a required field.'],
    },
    password: {
        type: String,
        minlength: [8, 'Password should be at least 8 characters.'],
        required: [true, 'Password is a required field.']
    }
});

userSchema.pre('save', async function(next){
    const key = await bcrypt.genSalt();
    this.password = await bcrypt.hash(this.password, key);
    next();
});

userSchema.statics.signIn = async (uName, password) => {
    //try{
        const user = await User.findOne({ userName : uName });

        if(user){
            const isValidUser = await bcrypt.compare(password, user.password);

            if(isValidUser){
                return user; 
            }
            else{
                throw Error('Password mismatch.');
            }
        }
        else{
            throw Error('User does not exist.')
        }
    /*}
    catch(err){
        console.log(err);
    }*/
    
}

const User = mongoose.model('user', userSchema);

module.exports = User;